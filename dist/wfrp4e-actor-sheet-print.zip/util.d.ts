import jsPDF from 'jspdf';
export declare class Util {
    static getHeightFromPx(doc: jsPDF, size: number): number;
    static getAllActorItems(actor: Actor & any, keys: string[]): (Item & any)[];
    static getActorItems(actor: Actor & any, key: string): (Item & any)[];
}
