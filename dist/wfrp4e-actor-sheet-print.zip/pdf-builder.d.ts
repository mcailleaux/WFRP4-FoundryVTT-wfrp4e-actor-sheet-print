import jsPDF, { jsPDFOptions } from 'jspdf';
import { AbstractElement } from './elements/abstract-element';
export declare class PdfBuilder {
    doc: jsPDF;
    constructor(options: jsPDFOptions);
    build(elements: AbstractElement[]): void;
}
