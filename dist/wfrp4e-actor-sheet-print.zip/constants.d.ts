export declare const i18n: () => any;
export declare const i18nLocalize: (id: string) => any;
export declare const i18nFormat: (id: string, data?: any) => any;
export declare const TEXT_SIZE = 8;
export declare const LABEL_SIZE = 6;
export declare const MARGINS: {
    top: number;
    left: number;
    bottom: number;
    right: number;
};
