import { Row } from './row';
import jsPDF from 'jspdf';
export declare class LabelledValues extends Row {
    labelledValues: {
        label: string;
        value: number;
    }[];
    nbrOfCol: number;
    constructor(x: number, y: number, labelledValues: {
        label: string;
        value: number;
    }[], nbrOfCol?: number, multiline?: boolean);
    prepareRender(doc: jsPDF, maxWidth?: number): jsPDF;
    render(doc: jsPDF, _maxWidth?: number): jsPDF;
}
