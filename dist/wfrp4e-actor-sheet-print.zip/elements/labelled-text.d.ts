import jsPDF, { TextOptionsLight } from 'jspdf';
import { Text } from './text';
import { AbstractElement } from './abstract-element';
export declare class LabelledText extends Text {
    label: string;
    labelOptions?: TextOptionsLight;
    constructor(x: number, y: number, label: string, text: string, textOptions?: TextOptionsLight, labelOptions?: TextOptionsLight);
    prepareRender(doc: jsPDF, maxWidth?: number): jsPDF;
    render(doc: jsPDF, _maxWidth?: number): jsPDF;
    protected updateMaxWidth(maxWidth?: number): void;
    getHeight(doc: any): number;
    getCheckNewPageHeight(doc?: jsPDF): number;
    getElements(): AbstractElement[];
}
