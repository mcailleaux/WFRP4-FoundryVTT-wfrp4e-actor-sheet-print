import jsPDF from 'jspdf';
export declare abstract class AbstractElement {
    x: number;
    y: number;
    maxWidth?: number;
    constructor(x: number, y: number, maxWidth?: number | undefined);
    getHeightFromPx(doc: jsPDF, size: number): number;
    getPxFromSize(doc: jsPDF, size: number): number;
    protected updateMaxWidth(maxWidth?: number): void;
    abstract prepareRender(doc: jsPDF, maxWidth?: number): jsPDF;
    abstract render(doc: jsPDF, maxWidth?: number): jsPDF;
    abstract getHeight(doc?: jsPDF): number;
    abstract getCheckNewPageHeight(doc?: jsPDF): number;
    abstract getElements(): AbstractElement[];
}
