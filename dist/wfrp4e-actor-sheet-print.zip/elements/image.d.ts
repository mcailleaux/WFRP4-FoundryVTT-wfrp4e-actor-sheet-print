import { Box } from './box';
import jsPDF from 'jspdf';
import { AbstractElement } from './abstract-element';
export declare class Image extends Box {
    imageData: string;
    constructor(x: number, y: number, w: number, h: number, imageData: string);
    render(doc: jsPDF, _maxWidth?: number): jsPDF;
    getElements(): AbstractElement[];
}
