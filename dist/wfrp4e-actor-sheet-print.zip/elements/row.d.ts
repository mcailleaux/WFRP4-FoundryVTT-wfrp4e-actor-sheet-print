import { AbstractElement } from './abstract-element';
import jsPDF from 'jspdf';
export declare class Row extends AbstractElement {
    elements: AbstractElement[];
    widthPercents?: number[];
    maxWidths?: number[];
    constructor(x: number, y: number, elements: AbstractElement[], maxWidth?: number | undefined, widthPercents?: number[], maxWidths?: number[]);
    prepareRender(doc: jsPDF, maxWidth?: number): jsPDF;
    render(doc: jsPDF, _maxWidth?: number): jsPDF;
    getHeight(doc?: jsPDF): number;
    getCheckNewPageHeight(doc?: jsPDF): number;
    getElements(): AbstractElement[];
    isEmpty(): boolean;
}
