import { AbstractElement } from './abstract-element';
import jsPDF, { TextOptionsLight } from 'jspdf';
export declare class Text extends AbstractElement {
    text: string;
    textOptions?: TextOptionsLight;
    constructor(x: number, y: number, text: string, textOptions?: TextOptionsLight);
    prepareRender(doc: jsPDF, maxWidth?: number): jsPDF;
    render(doc: jsPDF, _maxWidth?: number): jsPDF;
    protected updateMaxWidth(maxWidth?: number): void;
    getHeight(doc: any): number;
    getCheckNewPageHeight(doc?: jsPDF): number;
    getElements(): AbstractElement[];
}
