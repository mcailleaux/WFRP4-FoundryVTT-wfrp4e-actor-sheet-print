import { AbstractElement } from './abstract-element';
import jsPDF from 'jspdf';
import { Box } from './box';
export declare class Blank extends Box {
    constructor(x: number, y: number, w: number, h: number);
    static heightBlank(h: number): Blank;
    getCheckNewPageHeight(doc?: jsPDF): number;
    prepareRender(doc: jsPDF, _maxWidth?: number): jsPDF;
    render(doc: jsPDF, _maxWidth?: number): jsPDF;
    getElements(): AbstractElement[];
}
