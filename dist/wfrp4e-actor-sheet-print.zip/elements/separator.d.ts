import { AbstractElement } from './abstract-element';
import jsPDF from 'jspdf';
export declare class Separator extends AbstractElement {
    constructor(x: number, y: number, maxWidth?: number | undefined);
    getHeight(_doc?: jsPDF): number;
    getCheckNewPageHeight(doc?: jsPDF): number;
    prepareRender(doc: jsPDF, _maxWidth?: number): jsPDF;
    render(doc: jsPDF, maxWidth?: number): jsPDF;
    getElements(): AbstractElement[];
}
