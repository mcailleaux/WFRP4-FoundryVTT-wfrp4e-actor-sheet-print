import { AbstractElement } from './abstract-element';
import jsPDF from 'jspdf';
export declare class Column extends AbstractElement {
    elements: AbstractElement[];
    constructor(x: number, y: number, elements: AbstractElement[]);
    prepareRender(doc: jsPDF, _maxWidth?: number): jsPDF;
    render(doc: jsPDF, _maxWidth?: number): jsPDF;
    getHeight(doc: any): number;
    getCheckNewPageHeight(doc?: jsPDF): number;
    getElements(): AbstractElement[];
    isEmpty(): boolean;
}
