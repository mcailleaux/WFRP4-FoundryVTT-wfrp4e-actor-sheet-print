import { AbstractElement } from './abstract-element';
import jsPDF, { TextOptionsLight } from 'jspdf';
import { Text } from './text';
export declare class MultilineText extends Text {
    private nbrLine;
    constructor(x: number, y: number, text: string, textOptions?: TextOptionsLight);
    prepareRender(doc: jsPDF, maxWidth?: number): jsPDF;
    render(doc: jsPDF, _maxWidth?: number): jsPDF;
    getHeight(doc: any): number;
    getElements(): AbstractElement[];
}
