import { AbstractElement } from './abstract-element';
import jsPDF from 'jspdf';
export declare class Box extends AbstractElement {
    w: number;
    h: number;
    constructor(x: number, y: number, w: number, h: number);
    prepareRender(doc: jsPDF, _maxWidth?: number): jsPDF;
    render(doc: jsPDF, _maxWidth?: number): jsPDF;
    getHeight(_doc: any): number;
    getCheckNewPageHeight(doc?: jsPDF): number;
    getElements(): AbstractElement[];
}
