import { Row } from './row';
export declare class LabelledValue extends Row {
    label: string;
    value: number;
    constructor(label: string, value: number, widthPercents?: number[], multiline?: boolean, maxWidth?: number);
}
