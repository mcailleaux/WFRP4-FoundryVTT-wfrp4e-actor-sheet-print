import { Row } from './row';
import jsPDF from 'jspdf';
export declare class Texts extends Row {
    texts: string[];
    nbrOfCol: number;
    constructor(x: number, y: number, texts: string[], nbrOfCol?: number, multiline?: boolean);
    prepareRender(doc: jsPDF, maxWidth?: number): jsPDF;
    render(doc: jsPDF, _maxWidth?: number): jsPDF;
}
